import os
os.environ['DATABASE_URL']='sqlite:////tmp/pocketsmart_test.db'
os.environ['SECRET_KEY']='test-secret-key'
os.environ['AI_ENABLED']='false'
from fastapi.testclient import TestClient
from app.main import app

client=TestClient(app)

def setup_module():
    import app.database as db
    db.init_db()

def test_health():
    assert client.get('/health').json()['status']=='ok'

def test_register_login_and_home():
    email='test@example.com'
    r=client.post('/register',data={'name':'Test User','email':email,'password':'password123'},follow_redirects=False)
    assert r.status_code in (303,409)
    r=client.post('/login',data={'email':email,'password':'password123'},follow_redirects=False)
    assert r.status_code==303
    r=client.post('/api/generate-home',json={'budget':50000,'rooms':['Living Room'],'style':'modern','location':'India','items':[{'category':'Ceiling fan','quantity':2}]})
    assert r.status_code==200
    data=r.json(); assert data['planner']=='home'; assert len(data['recommendations'])==1

def test_validation():
    r=client.post('/api/generate-party',json={'budget':-1,'guests':0,'event_type':'x'})
    assert r.status_code==401 or r.status_code==422
