from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from .config import get_settings
from .database import init_db
from .routers import api, auth, pages

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

settings=get_settings()
app=FastAPI(title=settings.app_name,version="1.0.0",description="Budget-aware AI recommendation assistant",lifespan=lifespan)
app.add_middleware(CORSMiddleware,allow_origins=settings.cors_origin_list,allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
app.mount("/static",StaticFiles(directory="app/static"),name="static")
app.include_router(pages.router)
app.include_router(auth.router)
app.include_router(api.router)
app.include_router(api.router, prefix="")

@app.get("/health")
def health(): return {"status":"ok","service":"PocketSmart AI"}

@app.get("/startup")
def startup_status(): return {"status":"ready","ai_enabled":settings.ai_enabled,"gemini_configured":bool(settings.gemini_api_key),"model":settings.gemini_model}

if __name__=="__main__":
    import uvicorn
    uvicorn.run("app.main:app",host="127.0.0.1",port=8000,reload=True)
