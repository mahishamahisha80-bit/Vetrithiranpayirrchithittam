from datetime import datetime, timedelta, timezone
from jose import JWTError, jwt
from passlib.context import CryptContext
from fastapi import Request
from .config import get_settings
from .database import get_db

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
ALGORITHM = "HS256"


def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(password: str, hashed: str) -> bool:
    return pwd_context.verify(password, hashed)

def create_access_token(user_id: int, minutes: int = 60 * 24) -> str:
    now = datetime.now(timezone.utc)
    return jwt.encode({"sub": str(user_id), "iat": now, "exp": now + timedelta(minutes=minutes)}, get_settings().secret_key, algorithm=ALGORITHM)

def user_from_token(token: str):
    try:
        payload = jwt.decode(token, get_settings().secret_key, algorithms=[ALGORITHM])
        user_id = int(payload["sub"])
    except (JWTError, KeyError, ValueError, TypeError):
        return None
    with get_db() as db:
        row = db.execute("SELECT id, name, email, created_at FROM users WHERE id=?", (user_id,)).fetchone()
        return dict(row) if row else None

def current_user(request: Request):
    token = request.cookies.get("access_token")
    return user_from_token(token) if token else None
