from typing import Literal
from pydantic import BaseModel, Field, field_validator

PlannerType = Literal["home", "party", "jewelry"]

class UserRegister(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    email: str = Field(min_length=5, max_length=200)
    password: str = Field(min_length=8, max_length=128)

class UserLogin(BaseModel):
    email: str
    password: str

class HomeItem(BaseModel):
    category: str = Field(min_length=2, max_length=80)
    quantity: int = Field(ge=1, le=50)

class HomeRequest(BaseModel):
    budget: float = Field(gt=0, le=10_000_000)
    rooms: list[str] = Field(min_length=1, max_length=10)
    style: str = Field(default="modern", max_length=100)
    items: list[HomeItem] = Field(min_length=1, max_length=30)
    location: str = Field(default="India", max_length=100)

class PartyRequest(BaseModel):
    budget: float = Field(gt=0, le=10_000_000)
    guests: int = Field(ge=1, le=5000)
    event_type: str = Field(min_length=2, max_length=80)
    venue: str = Field(default="Flexible", max_length=120)
    city: str = Field(default="India", max_length=100)
    preferences: str = Field(default="", max_length=1000)

class JewelryRequest(BaseModel):
    budget: float = Field(gt=0, le=10_000_000)
    occasion: str = Field(min_length=2, max_length=100)
    style: str = Field(default="elegant", max_length=100)
    metal: str = Field(default="any", max_length=50)
    outfit_description: str = Field(default="", max_length=1000)

class RecommendationItem(BaseModel):
    name: str
    category: str
    estimated_price: float = Field(ge=0)
    quantity: int = Field(default=1, ge=1)
    platform: str
    search_url: str
    reason: str

class BudgetAllocation(BaseModel):
    category: str
    amount: float = Field(ge=0)
    percentage: float = Field(ge=0, le=100)

class RecommendationResponse(BaseModel):
    planner: PlannerType
    title: str
    summary: str
    total_estimated: float = Field(ge=0)
    budget: float = Field(ge=0)
    budget_remaining: float
    allocations: list[BudgetAllocation] = []
    recommendations: list[RecommendationItem] = []
    tips: list[str] = []
    ai_generated: bool = False
    warning: str | None = None
