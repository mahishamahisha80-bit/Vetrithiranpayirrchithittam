# PocketSmart AI

A complete FastAPI + Jinja2 + SQLite + Gemini recommendation assistant implementing the supplied PocketSmart AI specification.

## Features
- Registration/login/logout with JWT stored in an HttpOnly cookie
- Home interior, party, and jewelry planners
- Optional jewelry outfit image analysis
- Gemini structured JSON recommendations when `GEMINI_API_KEY` is configured
- Deterministic local fallback recommendations when AI is unavailable
- Recommendation history and dashboard
- Adapter-based marketplace/vendor links for Amazon, Flipkart, IKEA, Swiggy, Zomato, and OYO
- API validation with Pydantic
- Automated tests
- Responsive frontend

## Important implementation note
The supplied document mentions both Flask and FastAPI. This implementation uses FastAPI consistently because its later milestones explicitly define FastAPI routes, Jinja2 templates, authentication, `/startup`, and Uvicorn startup. See the supplied architecture description. 

The document also calls for third-party marketplace APIs but does not provide credentials/contracts for those APIs. Therefore the app uses safe search links through an adapter layer rather than fake live prices or scraping. Replace the adapter implementation with licensed APIs when credentials/contracts are available.

## Quick start

### Windows PowerShell
```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
# Edit .env and add GEMINI_API_KEY if desired
uvicorn app.main:app --reload
```

### macOS/Linux
```bash
python3.11 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env and add GEMINI_API_KEY if desired
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000

API docs: http://127.0.0.1:8000/docs

## Test
```bash
pytest -q
```

## Gemini
The application uses Google's current `google-genai` SDK and a configurable `GEMINI_MODEL`. Structured JSON output is requested so the frontend receives predictable recommendation objects. The model can be changed in `.env` without code changes.

## Production checklist
- Set a strong random `SECRET_KEY`.
- Use PostgreSQL or another production DB instead of SQLite.
- Store uploads in object storage and scan files.
- Add CSRF protection for cookie-authenticated state-changing browser forms.
- Put the app behind HTTPS and a reverse proxy.
- Replace demo marketplace search adapters with licensed APIs/affiliate links where permitted.
- Add rate limiting and observability.
